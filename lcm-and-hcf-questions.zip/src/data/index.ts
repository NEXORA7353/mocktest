import { test1 } from "./test1";
import { test2 } from "./test2";
import { test3 } from "./test3";
import { test4 } from "./test4";
import type { MockTest } from "./types";

export const tests: MockTest[] = [test1, test2, test3, test4];

export function getTest(id: number): MockTest {
  return tests.find((t) => t.id === id) ?? tests[0];
}
