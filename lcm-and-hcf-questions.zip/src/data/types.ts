export type Topic = "lcm" | "percent";

export interface Question {
  id: number;
  topic: Topic;
  /** Exam(s) jahan ye prashn puchha gaya */
  exam: string;
  q: string;
  /** 4 real options A–D. Option E is reserved for "not attempting" (TRE 4.0 rules) */
  options: [string, string, string, string];
  /** index 0-3 of correct option */
  ans: 0 | 1 | 2 | 3;
  sol: string;
  /** true jab prashn kisi poorv mock se punravritti ke roop mein liya gaya ho */
  revision?: boolean;
}

export interface MockTest {
  id: number;
  code: string;
  title: string;
  tagline: string;
  tag: string;
  questions: Question[];
  durationMin: number;
}

export const TOPIC_LABEL: Record<Topic, string> = {
  lcm: "ल.स. – म.स.",
  percent: "प्रतिशत",
};

export type Response = number | "E" | null;

export interface ResultPayload {
  responses: Response[];
  /** milliseconds spent on each question */
  times: number[];
  timeUsedSec: number;
  autoSubmitted: boolean;
}
