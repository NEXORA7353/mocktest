import { useEffect, useState } from "react";
import {
  ArrowRight,
  Award,
  CheckCircle2,
  CircleDashed,
  GraduationCap,
  Hourglass,
  ListChecks,
  Sigma,
  SkipForward,
  Target,
  Timer,
  XCircle,
} from "lucide-react";
import { tests } from "../data";

const EXAMS = [
  "BPSC Tre 3.0 • 21/07/2024",
  "Bihar STET • 05/09/2023",
  "BPSC Tre 2.0 • 08/12/2023",
  "Bihar STET • 23/05/2024",
  "BPSC Tre 1.0 • 26/08/2023",
  "Bihar STET • 15/09/2020",
  "BPSC Tre 3.0 (6-8) • 15/03/2024",
  "Bihar STET • 28/01/2020",
];

const SCHEME = [
  {
    icon: CheckCircle2,
    title: "सही उत्तर",
    value: "+1 अंक",
    desc: "प्रत्येक सही उत्तर पर पूरा 1 अंक",
    cls: "text-emerald-400 border-emerald-400/25 bg-emerald-400/10",
  },
  {
    icon: XCircle,
    title: "गलत उत्तर",
    value: "−⅓ अंक",
    desc: "हर गलत उत्तर पर एक-तिहाई अंक कटेगा",
    cls: "text-rose-400 border-rose-400/25 bg-rose-400/10",
  },
  {
    icon: SkipForward,
    title: "विकल्प E चुनें",
    value: "0 अंक",
    desc: "उत्तर न देना हो तो E चुनें — कोई कटौती नहीं",
    cls: "text-sky-400 border-sky-400/25 bg-sky-400/10",
  },
  {
    icon: CircleDashed,
    title: "खाली छोड़ा",
    value: "−⅓ अंक",
    desc: "कुछ भी न चुनने पर भी एक-तिहाई कटेगा",
    cls: "text-amber-400 border-amber-400/25 bg-amber-400/10",
  },
  {
    icon: Hourglass,
    title: "समय प्रबंधन",
    value: "1 मिनट / प्रश्न",
    desc: "150 प्रश्न = 150 मिनट का TRE अनुपात लागू",
    cls: "text-violet-400 border-violet-400/25 bg-violet-400/10",
  },
];

export default function Landing({ onSelect }: { onSelect: (testId: number) => void }) {
  const [best, setBest] = useState<Record<number, number>>({});

  useEffect(() => {
    const b: Record<number, number> = {};
    tests.forEach((t) => {
      const raw = window.localStorage.getItem(`tre4-best-${t.id}`);
      if (raw !== null) b[t.id] = Number(raw);
    });
    setBest(b);
  }, []);

  return (
    <div className="dark-mesh grain relative min-h-screen overflow-hidden">
      <div className="dark-grid-lines pointer-events-none absolute inset-0" />

      {/* ---------- NAV ---------- */}
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 pt-6">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-saffron-500 text-ink-950 shadow-[0_0_36px_rgba(245,165,36,0.35)]">
            <Sigma className="h-6 w-6" strokeWidth={2.5} />
          </div>
          <div>
            <p className="text-sm font-extrabold tracking-wide">TRE 4.0 गणित मॉक</p>
            <p className="font-latin text-[10px] font-semibold uppercase tracking-[0.28em] text-white/45">
              LCM-HCF × Percentage
            </p>
          </div>
        </div>
        <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-semibold text-white/70 sm:flex">
          <GraduationCap className="h-4 w-4 text-saffron-400" />
          BPSC TRE 4.0 पैटर्न (A–E विकल्प)
        </div>
      </header>

      {/* ---------- HERO ---------- */}
      <section className="relative z-10 mx-auto max-w-6xl px-5 pt-14 pb-10 sm:pt-20">
        <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-saffron-500/30 bg-saffron-500/10 px-4 py-1.5 text-xs font-bold text-saffron-300">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-saffron-400 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-saffron-400" />
          </span>
          Bihar STET + BPSC Tre 1.0 / 2.0 / 3.0 के वास्तविक प्रश्न
        </div>

        <h1
          className="animate-rise mt-6 max-w-4xl text-[clamp(2.4rem,7.2vw,5rem)] leading-[1.06] font-extrabold tracking-tight"
          style={{ animationDelay: "80ms" }}
        >
          परीक्षा-हॉल वाली फील,
          <br />
          <span className="bg-gradient-to-r from-saffron-300 via-saffron-500 to-amber-600 bg-clip-text text-transparent">
            +1 और −⅓ वाला दबाव,
          </span>
          <br />
          अब आपकी स्क्रीन पर।
        </h1>

        <p
          className="animate-rise mt-6 max-w-2xl text-base leading-relaxed text-white/60 sm:text-lg"
          style={{ animationDelay: "160ms" }}
        >
          लघुत्तम–महत्तम समापवर्त्य (LCM-HCF) और प्रतिशत के{" "}
          <span className="font-bold text-white/85">106 यूनिक एग्ज़ाम-प्रश्न</span>, TRE 4.0 के नए
          5-विकल्प नियम के साथ — खाली छोड़ने पर भी{" "}
          <span className="font-bold text-rose-300">−⅓</span> कटता है, इसलिए उत्तर न देना हो तो{" "}
          <span className="font-bold text-sky-300">E</span> चुनना न भूलें। हर प्रश्न का{" "}
          <span className="font-bold text-white/85">समय-विश्लेषण</span> भी मिलेगा।
        </p>

        <div
          className="animate-rise mt-9 grid max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4"
          style={{ animationDelay: "240ms" }}
        >
          {[
            { v: "04", l: "मॉक टेस्ट" },
            { v: "120", l: "प्रश्न स्लॉट" },
            { v: "106", l: "यूनिक प्रश्न" },
            { v: "30 मि.", l: "प्रत्येक टेस्ट" },
          ].map((s) => (
            <div
              key={s.l}
              className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 backdrop-blur"
            >
              <p className="font-latin text-2xl font-extrabold text-saffron-400">{s.v}</p>
              <p className="mt-0.5 text-xs font-semibold text-white/55">{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- EXAM MARQUEE ---------- */}
      <div className="relative z-10 border-y border-white/10 bg-white/[0.03] py-3.5">
        <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
          {[...EXAMS, ...EXAMS].map((e, i) => (
            <span
              key={i}
              className="flex items-center gap-3 text-xs font-bold tracking-wider text-white/45"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-saffron-500/70" />
              {e}
            </span>
          ))}
        </div>
      </div>

      {/* ---------- MARKING SCHEME ---------- */}
      <section className="relative z-10 mx-auto max-w-6xl px-5 pt-14">
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
            TRE 4.0 <span className="text-saffron-400">मार्किंग स्कीम</span>
          </h2>
          <p className="hidden max-w-xs text-right text-xs leading-relaxed text-white/40 sm:block">
            असली TRE 4.0 नियम — E न चुनना भी महँगा पड़ सकता है
          </p>
        </div>
        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {SCHEME.map((s) => (
            <div
              key={s.title}
              className="group rounded-2xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur transition-colors hover:border-white/20"
            >
              <div className={`grid h-10 w-10 place-items-center rounded-xl border ${s.cls}`}>
                <s.icon className="h-5 w-5" />
              </div>
              <p className="mt-4 text-xs font-bold text-white/50">{s.title}</p>
              <p className="mt-1 font-latin text-xl font-extrabold text-white">{s.value}</p>
              <p className="mt-2 text-xs leading-relaxed text-white/45">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- TEST CARDS ---------- */}
      <section className="relative z-10 mx-auto max-w-6xl px-5 py-14">
        <div className="flex items-end justify-between">
          <h2 className="text-2xl font-extrabold tracking-tight sm:text-3xl">
            अपना <span className="text-saffron-400">मॉक टेस्ट</span> चुनें
          </h2>
          <p className="hidden text-xs text-white/40 sm:block">
            प्रत्येक में LCM-HCF और प्रतिशत बारी-बारी से
          </p>
        </div>

        <div className="mt-7 grid grid-cols-1 gap-5 md:grid-cols-2">
          {tests.map((t) => (
            <article
              key={t.id}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-ink-850 to-ink-900 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-saffron-500/40 hover:shadow-[0_24px_60px_-24px_rgba(245,165,36,0.25)] sm:p-7"
            >
              <span className="num-outline pointer-events-none absolute -top-5 right-3 font-latin text-[7rem] font-extrabold leading-none">
                {String(t.id).padStart(2, "0")}
              </span>

              <div className="relative">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full border border-saffron-500/40 bg-saffron-500/10 px-3 py-1 font-latin text-[10px] font-extrabold uppercase tracking-[0.2em] text-saffron-300">
                    {t.code}
                  </span>
                  <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] font-bold tracking-wider text-white/55">
                    {t.tag}
                  </span>
                </div>

                <h3 className="mt-4 text-2xl font-extrabold tracking-tight text-white">
                  {t.title}
                </h3>
                <p className="mt-1.5 text-sm leading-relaxed text-white/50">{t.tagline}</p>

                <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-xs font-semibold text-white/60">
                  <span className="flex items-center gap-1.5">
                    <ListChecks className="h-4 w-4 text-saffron-400" /> 30 प्रश्न
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Timer className="h-4 w-4 text-saffron-400" /> 30 मिनट
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Target className="h-4 w-4 text-saffron-400" /> 30 अंक
                  </span>
                </div>

                {/* topic split */}
                <div className="mt-5">
                  <div className="flex h-2 overflow-hidden rounded-full">
                    <div className="w-1/2 bg-indigo-500" />
                    <div className="w-1/2 bg-saffron-500" />
                  </div>
                  <div className="mt-2 flex justify-between text-[10px] font-bold tracking-wider text-white/45">
                    <span className="flex items-center gap-1.5">
                      <span className="h-1.5 w-1.5 rounded-full bg-indigo-400" /> ल.स.–म.स. • 15
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-1.5 w-1.5 rounded-full bg-saffron-400" /> प्रतिशत • 15
                    </span>
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between gap-3">
                  {best[t.id] !== undefined ? (
                    <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                      <Award className="h-4 w-4" />
                      सर्वश्रेष्ठ: {best[t.id].toFixed(2)}/30
                    </span>
                  ) : (
                    <span className="text-xs font-semibold text-white/35">
                      अभी कोई प्रयास नहीं
                    </span>
                  )}
                  <button
                    onClick={() => onSelect(t.id)}
                    className="flex items-center gap-2 rounded-xl bg-saffron-500 px-5 py-3 text-sm font-extrabold text-ink-950 transition-all hover:bg-saffron-400 active:scale-95"
                  >
                    टेस्ट शुरू करें
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ---------- FOOTER ---------- */}
      <footer className="relative z-10 border-t border-white/10 py-8">
        <p className="mx-auto max-w-6xl px-5 text-center text-xs leading-relaxed text-white/35">
          यह अभ्यास मंच YCT प्रश्नोत्तर संकलन (ल.स.–म.स. एवं प्रतिशत) पर आधारित है • प्रत्येक प्रश्न
          के साथ उसका वास्तविक परीक्षा-स्रोत अंकित है • रिज़ल्ट में प्रति-प्रश्न समय विश्लेषण और
          पूर्ण व्याख्या उपलब्ध
        </p>
      </footer>
    </div>
  );
}
