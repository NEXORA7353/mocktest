import { useEffect, useRef, useState } from "react";
import {
  AlarmClock,
  ChevronLeft,
  ChevronRight,
  CircleDashed,
  Eraser,
  Flag,
  Landmark,
  LayoutGrid,
  ListChecks,
  RotateCcw,
  Send,
  Sigma,
  SkipForward,
  TriangleAlert,
  X,
} from "lucide-react";
import type { MockTest, Response, ResultPayload, Topic } from "../data/types";
import { TOPIC_LABEL } from "../data/types";

const LETTERS = ["A", "B", "C", "D"] as const;

function fmtClock(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

const TOPIC_CHIP: Record<Topic, string> = {
  lcm: "border-indigo-300 bg-indigo-50 text-indigo-700",
  percent: "border-amber-300 bg-amber-50 text-amber-700",
};

function paletteClass(status: string, isCurrent: boolean) {
  const base =
    "relative h-10 w-full rounded-lg border text-sm font-extrabold transition-all active:scale-90 ";
  const current = isCurrent
    ? "ring-2 ring-slate-900 ring-offset-2 ring-offset-[#eef1f8] "
    : "";
  switch (status) {
    case "ans":
      return base + current + "bg-emerald-600 border-emerald-600 text-white";
    case "skip":
      return base + current + "bg-sky-600 border-sky-600 text-white";
    case "mark":
      return base + current + "bg-violet-600 border-violet-600 text-white";
    case "ansmark":
      return base + current + "bg-emerald-600 border-emerald-600 text-white";
    case "seen":
      return base + current + "bg-rose-50 border-rose-400 text-rose-700";
    default:
      return base + current + "bg-white border-slate-300 text-slate-500 hover:border-slate-500";
  }
}

export default function TestRunner({
  test,
  onFinish,
  onQuit,
}: {
  test: MockTest;
  onFinish: (payload: ResultPayload) => void;
  onQuit: () => void;
}) {
  const n = test.questions.length;
  const totalSec = test.durationMin * 60;

  const [current, setCurrent] = useState(0);
  const [responses, setResponses] = useState<Response[]>(() => Array(n).fill(null));
  const [marked, setMarked] = useState<boolean[]>(() => Array(n).fill(false));
  const [visited, setVisited] = useState<boolean[]>(() => {
    const v = Array(n).fill(false);
    v[0] = true;
    return v;
  });
  const [timeLeft, setTimeLeft] = useState(totalSec);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const timesRef = useRef<number[]>(Array(n).fill(0));
  const lastSwitchRef = useRef<number>(Date.now());
  const endAtRef = useRef<number>(Date.now() + totalSec * 1000);
  const responsesRef = useRef<Response[]>(responses);
  const currentRef = useRef(0);
  const submittedRef = useRef(false);

  responsesRef.current = responses;
  currentRef.current = current;

  /* per-question time accumulation */
  useEffect(() => {
    lastSwitchRef.current = Date.now();
    return () => {
      timesRef.current[current] += Date.now() - lastSwitchRef.current;
    };
  }, [current]);

  const submit = (auto: boolean) => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    timesRef.current[currentRef.current] += Date.now() - lastSwitchRef.current;
    const left = Math.max(0, Math.round((endAtRef.current - Date.now()) / 1000));
    onFinish({
      responses: [...responsesRef.current],
      times: [...timesRef.current],
      timeUsedSec: totalSec - left,
      autoSubmitted: auto,
    });
  };

  /* countdown */
  useEffect(() => {
    const id = window.setInterval(() => {
      const left = Math.max(0, Math.round((endAtRef.current - Date.now()) / 1000));
      setTimeLeft(left);
      if (left <= 0) {
        window.clearInterval(id);
        submit(true);
      }
    }, 500);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const goTo = (i: number) => {
    const idx = Math.max(0, Math.min(n - 1, i));
    setVisited((v) => {
      if (v[idx]) return v;
      const c = [...v];
      c[idx] = true;
      return c;
    });
    setCurrent(idx);
    setPaletteOpen(false);
  };

  const choose = (r: Exclude<Response, null>) => {
    setResponses((rs) => {
      const c = [...rs];
      c[current] = r;
      return c;
    });
  };

  const clearResponse = () =>
    setResponses((rs) => {
      const c = [...rs];
      c[current] = null;
      return c;
    });

  const toggleMark = () =>
    setMarked((m) => {
      const c = [...m];
      c[current] = !c[current];
      return c;
    });

  const q = test.questions[current];
  const resp = responses[current];

  const statusOf = (i: number) => {
    const r = responses[i];
    const m = marked[i];
    if (m && r !== null) return "ansmark";
    if (m) return "mark";
    if (r !== null) return r === "E" ? "skip" : "ans";
    if (visited[i]) return "seen";
    return "idle";
  };

  const answeredCount = responses.filter((r) => r !== null).length;
  const answeredAD = responses.filter((r) => typeof r === "number").length;
  const eCount = responses.filter((r) => r === "E").length;
  const blankCount = n - answeredCount;
  const markedCount = marked.filter(Boolean).length;

  const lowTime = timeLeft <= 300;
  const critical = timeLeft <= 60;

  const paletteBlock = (
    <>
      <div className="grid grid-cols-6 gap-2 sm:grid-cols-6 lg:grid-cols-5">
        {test.questions.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className={paletteClass(statusOf(i), i === current)}
            aria-label={`प्रश्न ${i + 1}`}
          >
            {i + 1}
            {statusOf(i) === "ansmark" && (
              <span className="palette-dot bg-violet-500" />
            )}
          </button>
        ))}
      </div>
      <div className="mt-5 grid grid-cols-2 gap-x-3 gap-y-2.5 border-t border-slate-200 pt-4 text-[11px] font-semibold text-slate-600">
        <span className="flex items-center gap-2">
          <span className="h-3.5 w-3.5 rounded-md border border-slate-300 bg-white" /> नहीं देखा
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3.5 w-3.5 rounded-md border border-rose-400 bg-rose-50" /> अनुत्तरित
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3.5 w-3.5 rounded-md bg-emerald-600" /> उत्तर दिया
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3.5 w-3.5 rounded-md bg-sky-600" /> E से छोड़ा
        </span>
        <span className="flex items-center gap-2">
          <span className="h-3.5 w-3.5 rounded-md bg-violet-600" /> समीक्षा चिह्नित
        </span>
        <span className="flex items-center gap-2">
          <span className="relative h-3.5 w-3.5 rounded-md bg-emerald-600">
            <span className="palette-dot bg-violet-500" style={{ width: 6, height: 6, top: 1, right: 1 }} />
          </span>
          उत्तर + समीक्षा
        </span>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#eef1f8] exam-grid select-none">
      {/* ================= HEADER ================= */}
      <header className="sticky top-0 z-40 bg-[#101c36] text-white shadow-lg shadow-slate-950/20">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
          <div className="hidden h-9 w-9 place-items-center rounded-xl bg-white/10 sm:grid">
            <Sigma className="h-5 w-5 text-saffron-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-extrabold leading-tight">
              {test.title} <span className="text-white/40">•</span>{" "}
              <span className="text-saffron-400">गणित</span>
            </p>
            <p className="font-latin text-[9px] font-bold uppercase tracking-[0.22em] text-white/40">
              {test.code} · TRE 4.0 PATTERN
            </p>
          </div>

          <div className="hidden items-center gap-1.5 rounded-full bg-white/10 px-3.5 py-1.5 text-xs font-bold text-white/80 sm:flex">
            <ListChecks className="h-3.5 w-3.5 text-emerald-400" />
            उत्तरित {answeredCount}/{n}
          </div>

          <div
            className={`flex items-center gap-2 rounded-full px-4 py-1.5 font-mono text-base font-bold tabular-nums transition-colors ${
              critical
                ? "animate-pulse-soft bg-rose-500 text-white"
                : lowTime
                  ? "bg-rose-500/20 text-rose-200 ring-1 ring-rose-400/50"
                  : "bg-white/10 text-white"
            }`}
          >
            <AlarmClock className="h-4 w-4" />
            {fmtClock(timeLeft)}
          </div>

          <button
            onClick={() => setConfirmOpen(true)}
            className="flex items-center gap-2 rounded-xl bg-saffron-500 px-3.5 py-2 text-sm font-extrabold text-ink-950 transition-all hover:bg-saffron-400 active:scale-95 sm:px-5"
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline">सबमिट</span>
          </button>

          <button
            onClick={onQuit}
            className="grid h-9 w-9 place-items-center rounded-xl bg-white/10 text-white/60 transition-colors hover:bg-white/20 hover:text-white"
            title="टेस्ट छोड़ें"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>
        {/* progress hairline */}
        <div className="h-1 w-full bg-white/10">
          <div
            className="h-full bg-gradient-to-r from-saffron-500 to-amber-300 transition-all duration-500"
            style={{ width: `${(answeredCount / n) * 100}%` }}
          />
        </div>
      </header>

      {/* ================= BODY ================= */}
      <main className="mx-auto grid max-w-7xl gap-6 px-4 pt-6 pb-32 sm:px-6 lg:grid-cols-[1fr_320px] lg:pb-12">
        {/* ---------- question card ---------- */}
        <section key={current} className="animate-pop rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
          {/* meta row */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-[#101c36] px-3.5 py-1 font-latin text-[11px] font-extrabold tracking-wider text-white">
              प्रश्न {current + 1} / {n}
            </span>
            <span className={`rounded-full border px-3 py-1 text-[11px] font-extrabold ${TOPIC_CHIP[q.topic]}`}>
              {TOPIC_LABEL[q.topic]}
            </span>
            {q.revision && (
              <span className="flex items-center gap-1 rounded-full border border-teal-300 bg-teal-50 px-3 py-1 text-[11px] font-extrabold text-teal-700">
                <RotateCcw className="h-3 w-3" /> रिवीजन
              </span>
            )}
            {marked[current] && (
              <span className="flex items-center gap-1 rounded-full border border-violet-300 bg-violet-50 px-3 py-1 text-[11px] font-extrabold text-violet-700">
                <Flag className="h-3 w-3" /> समीक्षा
              </span>
            )}
          </div>

          <p className="mt-3 flex items-start gap-1.5 text-[11px] font-semibold leading-relaxed text-slate-400">
            <Landmark className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {q.exam}
          </p>

          {/* question */}
          <h2 className="mt-4 text-[17px] font-semibold leading-[1.75] text-slate-900 sm:text-lg sm:leading-[1.8]">
            {q.q}
          </h2>

          {/* options A-D */}
          <div className="mt-6 space-y-2.5">
            {q.options.map((opt, i) => {
              const selected = resp === i;
              return (
                <button
                  key={i}
                  onClick={() => choose(i)}
                  className={`flex w-full items-center gap-3.5 rounded-2xl border-2 px-4 py-3.5 text-left transition-all active:scale-[0.99] ${
                    selected
                      ? "border-emerald-600 bg-emerald-50 shadow-[0_6px_18px_-8px_rgba(5,150,105,0.45)]"
                      : "border-slate-200 bg-slate-50/70 hover:border-slate-400 hover:bg-white"
                  }`}
                >
                  <span
                    className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl border-2 font-latin text-sm font-extrabold transition-colors ${
                      selected
                        ? "border-emerald-600 bg-emerald-600 text-white"
                        : "border-slate-300 bg-white text-slate-500"
                    }`}
                  >
                    {LETTERS[i]}
                  </span>
                  <span className={`text-[15px] font-semibold leading-relaxed ${selected ? "text-emerald-950" : "text-slate-700"}`}>
                    {opt}
                  </span>
                </button>
              );
            })}

            {/* option E — do not answer */}
            <button
              onClick={() => choose("E")}
              className={`flex w-full items-center gap-3.5 rounded-2xl border-2 border-dashed px-4 py-3.5 text-left transition-all active:scale-[0.99] ${
                resp === "E"
                  ? "border-sky-600 bg-sky-50 shadow-[0_6px_18px_-8px_rgba(2,132,199,0.45)]"
                  : "border-sky-300 bg-sky-50/60 hover:border-sky-500 hover:bg-sky-50"
              }`}
            >
              <span
                className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl border-2 font-latin text-sm font-extrabold transition-colors ${
                  resp === "E" ? "border-sky-600 bg-sky-600 text-white" : "border-sky-300 bg-white text-sky-600"
                }`}
              >
                E
              </span>
              <span className="flex-1">
                <span className={`block text-[15px] font-semibold ${resp === "E" ? "text-sky-950" : "text-sky-800"}`}>
                  उत्तर नहीं देना है — प्रश्न छोड़ें
                </span>
                <span className="mt-0.5 flex items-center gap-1 text-[11px] font-semibold text-sky-600">
                  <SkipForward className="h-3 w-3" /> E चुनने पर कोई अंक नहीं कटेगा
                </span>
              </span>
            </button>
          </div>

          <p className="mt-5 flex items-start gap-2 rounded-xl bg-amber-50 px-4 py-3 text-[11px] font-semibold leading-relaxed text-amber-800">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
            TRE 4.0 नियम: A–E में से कुछ भी न चुनने पर भी −⅓ अंक कटेगा। उत्तर न आए तो E चुनना सबसे सुरक्षित है।
          </p>
        </section>

        {/* ---------- desktop palette ---------- */}
        <aside className="sticky top-24 hidden h-fit rounded-3xl border border-slate-200 bg-white p-5 shadow-sm lg:block">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-extrabold text-slate-800">
              <LayoutGrid className="h-4 w-4 text-slate-500" /> प्रश्न पैलेट
            </h3>
            <span className="font-latin text-[10px] font-extrabold tracking-widest text-slate-400 uppercase">
              {answeredCount}/{n}
            </span>
          </div>
          {paletteBlock}
          <button
            onClick={() => setConfirmOpen(true)}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#101c36] px-4 py-3 text-sm font-extrabold text-white transition-all hover:bg-ink-700 active:scale-[0.98]"
          >
            <Send className="h-4 w-4 text-saffron-400" /> टेस्ट सबमिट करें
          </button>
        </aside>
      </main>

      {/* ================= FOOTER ACTION BAR ================= */}
      <footer className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-2 px-3 py-3 sm:gap-3 sm:px-6">
          <button
            onClick={() => goTo(current - 1)}
            disabled={current === 0}
            className="flex items-center gap-1.5 rounded-xl border-2 border-slate-200 bg-white px-3 py-2.5 text-sm font-extrabold text-slate-700 transition-all hover:border-slate-400 active:scale-95 disabled:opacity-35 sm:px-5"
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="hidden sm:inline">पिछला</span>
          </button>

          <button
            onClick={clearResponse}
            disabled={resp === null}
            className="flex items-center gap-1.5 rounded-xl border-2 border-slate-200 bg-white px-3 py-2.5 text-sm font-extrabold text-slate-600 transition-all hover:border-rose-300 hover:text-rose-600 active:scale-95 disabled:opacity-35 sm:px-5"
          >
            <Eraser className="h-4 w-4" />
            <span className="hidden sm:inline">साफ़ करें</span>
          </button>

          <button
            onClick={toggleMark}
            className={`flex items-center gap-1.5 rounded-xl border-2 px-3 py-2.5 text-sm font-extrabold transition-all active:scale-95 sm:px-5 ${
              marked[current]
                ? "border-violet-600 bg-violet-600 text-white"
                : "border-slate-200 bg-white text-slate-600 hover:border-violet-400 hover:text-violet-700"
            }`}
          >
            <Flag className="h-4 w-4" />
            <span className="hidden sm:inline">{marked[current] ? "चिह्न हटाएँ" : "समीक्षा"}</span>
          </button>

          <div className="flex-1" />

          <button
            onClick={() => setPaletteOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border-2 border-slate-900 bg-slate-900 px-3 py-2.5 text-sm font-extrabold text-white transition-all active:scale-95 sm:px-5 lg:hidden"
          >
            <LayoutGrid className="h-4 w-4" />
            <span className="font-latin">{current + 1}/{n}</span>
          </button>

          {current < n - 1 ? (
            <button
              onClick={() => goTo(current + 1)}
              className="flex items-center gap-1.5 rounded-xl bg-saffron-500 px-4 py-2.5 text-sm font-extrabold text-ink-950 transition-all hover:bg-saffron-400 active:scale-95 sm:px-6"
            >
              अगला
              <ChevronRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              onClick={() => setConfirmOpen(true)}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-extrabold text-white transition-all hover:bg-emerald-500 active:scale-95 sm:px-6"
            >
              <Send className="h-4 w-4" />
              समाप्त करें
            </button>
          )}
        </div>
      </footer>

      {/* ================= MOBILE PALETTE SHEET ================= */}
      {paletteOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
            onClick={() => setPaletteOpen(false)}
          />
          <div className="animate-rise absolute inset-x-0 bottom-0 max-h-[78vh] overflow-y-auto rounded-t-3xl bg-white p-5 nice-scroll">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-base font-extrabold text-slate-800">
                <LayoutGrid className="h-5 w-5 text-slate-500" /> प्रश्न पैलेट
              </h3>
              <button
                onClick={() => setPaletteOpen(false)}
                className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100 text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {paletteBlock}
            <button
              onClick={() => {
                setPaletteOpen(false);
                setConfirmOpen(true);
              }}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#101c36] px-4 py-3.5 text-sm font-extrabold text-white"
            >
              <Send className="h-4 w-4 text-saffron-400" /> टेस्ट सबमिट करें
            </button>
          </div>
        </div>
      )}

      {/* ================= SUBMIT CONFIRM MODAL ================= */}
      {confirmOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <div
            className="absolute inset-0 bg-slate-950/65 backdrop-blur-sm"
            onClick={() => setConfirmOpen(false)}
          />
          <div className="animate-pop relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="bg-[#101c36] px-6 py-5 text-white">
              <h3 className="text-lg font-extrabold">फाइनल सबमिट की पुष्टि करें</h3>
              <p className="mt-0.5 text-xs font-semibold text-white/55">
                सबमिट के बाद कोई बदलाव संभव नहीं होगा
              </p>
            </div>

            <div className="space-y-2.5 px-6 py-5">
              <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-800">
                <span>उत्तर दिए गए (A–D)</span>
                <span className="font-latin text-base font-extrabold">{answeredAD}</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-sky-50 px-4 py-3 text-sm font-bold text-sky-800">
                <span className="flex items-center gap-2">
                  <SkipForward className="h-4 w-4" /> E से छोड़े गए (0 अंक)
                </span>
                <span className="font-latin text-base font-extrabold">{eCount}</span>
              </div>
              <div
                className={`flex items-center justify-between rounded-xl px-4 py-3 text-sm font-bold ${
                  blankCount > 0 ? "bg-rose-50 text-rose-800" : "bg-slate-50 text-slate-600"
                }`}
              >
                <span className="flex items-center gap-2">
                  <CircleDashed className="h-4 w-4" /> खाली (कोई विकल्प नहीं)
                </span>
                <span className="font-latin text-base font-extrabold">{blankCount}</span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-violet-50 px-4 py-3 text-sm font-bold text-violet-800">
                <span className="flex items-center gap-2">
                  <Flag className="h-4 w-4" /> समीक्षा हेतु चिह्नित
                </span>
                <span className="font-latin text-base font-extrabold">{markedCount}</span>
              </div>

              {blankCount > 0 && (
                <p className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-[11px] font-bold leading-relaxed text-rose-700">
                  <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
                  {blankCount} खाली प्रश्न पर −⅓ अंक प्रत्येक कटेगा — अर्थात −
                  {(blankCount / 3).toFixed(2)} अंक। E चुनकर इसे बचाया जा सकता है!
                </p>
              )}
            </div>

            <div className="flex gap-3 px-6 pb-6">
              <button
                onClick={() => setConfirmOpen(false)}
                className="flex-1 rounded-xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-extrabold text-slate-700 transition-all hover:border-slate-400 active:scale-[0.98]"
              >
                टेस्ट जारी रखें
              </button>
              <button
                onClick={() => submit(false)}
                className="flex-[1.3] rounded-xl bg-emerald-600 px-4 py-3 text-sm font-extrabold text-white transition-all hover:bg-emerald-500 active:scale-[0.98]"
              >
                फाइनल सबमिट
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
