import { useEffect, useMemo, useState } from "react";
import {
  Award,
  CheckCircle2,
  ChevronDown,
  CircleDashed,
  Gauge,
  Home,
  Landmark,
  RotateCcw,
  SkipForward,
  Target,
  Timer,
  TriangleAlert,
  XCircle,
  Zap,
  ArrowRight,
} from "lucide-react";
import type { MockTest, ResultPayload } from "../data/types";
import { TOPIC_LABEL } from "../data/types";

type Status = "correct" | "wrong" | "skip" | "blank";

const LETTERS = ["A", "B", "C", "D"];

const STATUS_META: Record<
  Status,
  { label: string; chip: string; bar: string; dot: string }
> = {
  correct: {
    label: "सही",
    chip: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300",
    bar: "bg-emerald-500",
    dot: "text-emerald-400",
  },
  wrong: {
    label: "गलत",
    chip: "border-rose-400/40 bg-rose-400/10 text-rose-300",
    bar: "bg-rose-500",
    dot: "text-rose-400",
  },
  skip: {
    label: "E — छोड़ा",
    chip: "border-sky-400/40 bg-sky-400/10 text-sky-300",
    bar: "bg-sky-500",
    dot: "text-sky-400",
  },
  blank: {
    label: "खाली",
    chip: "border-amber-400/40 bg-amber-400/10 text-amber-300",
    bar: "bg-amber-500",
    dot: "text-amber-400",
  },
};

function fmtDur(totalSec: number) {
  const s = Math.round(totalSec);
  if (s < 60) return `${s} से०`;
  const m = Math.floor(s / 60);
  return `${m} मि० ${s % 60} से०`;
}

export default function Result({
  test,
  payload,
  onRetry,
  onHome,
  onNext,
}: {
  test: MockTest;
  payload: ResultPayload;
  onRetry: () => void;
  onHome: () => void;
  onNext?: () => void;
}) {
  const [filter, setFilter] = useState<"all" | "wrong" | "skip">("all");
  const [open, setOpen] = useState<Set<number>>(new Set());
  const [newBest, setNewBest] = useState(false);

  const records = useMemo(
    () =>
      test.questions.map((q, i) => {
        const r = payload.responses[i];
        const status: Status =
          r === null ? "blank" : r === "E" ? "skip" : r === q.ans ? "correct" : "wrong";
        return { q, i, r, status, sec: Math.max(0, payload.times[i] / 1000) };
      }),
    [test, payload]
  );

  const c = useMemo(() => {
    const correct = records.filter((x) => x.status === "correct").length;
    const wrong = records.filter((x) => x.status === "wrong").length;
    const skip = records.filter((x) => x.status === "skip").length;
    const blank = records.filter((x) => x.status === "blank").length;
    return { correct, wrong, skip, blank };
  }, [records]);

  const score = c.correct - (c.wrong + c.blank) / 3;
  const maxScore = test.questions.length;
  const pct = Math.max(0, Math.min(100, (score / maxScore) * 100));
  const accuracy =
    c.correct + c.wrong > 0 ? Math.round((c.correct / (c.correct + c.wrong)) * 100) : 0;

  const grade =
    score >= 24
      ? { label: "उत्कृष्ट प्रदर्शन", color: "#34d399" }
      : score >= 18
        ? { label: "बहुत अच्छा प्रयास", color: "#2dd4bf" }
        : score >= 12
          ? { label: "औसत — अभ्यास जारी रखें", color: "#fbbf24" }
          : { label: "पुनः तैयारी आवश्यक", color: "#fb7185" };

  /* best score persistence */
  useEffect(() => {
    const key = `tre4-best-${test.id}`;
    const prev = Number(window.localStorage.getItem(key) ?? "-999");
    if (score > prev) {
      window.localStorage.setItem(key, String(score));
      if (prev > -900) setNewBest(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* time analytics */
  const timeStats = useMemo(() => {
    const secs = records.map((x) => x.sec);
    const max = Math.max(...secs);
    const scaleMax = Math.max(90, Math.ceil(max / 30) * 30);
    let fastest = 0;
    let slowest = 0;
    records.forEach((x, i) => {
      if (x.sec < records[fastest].sec) fastest = i;
      if (x.sec > records[slowest].sec) slowest = i;
    });
    const overTarget = records.filter((x) => x.sec > 60).length;
    const lightning = records.filter((x) => x.sec < 15).length;
    const avg = payload.timeUsedSec / records.length;
    return { scaleMax, fastest, slowest, overTarget, lightning, avg, max };
  }, [records, payload.timeUsedSec]);

  const filtered = records.filter((x) => {
    if (filter === "wrong") return x.status === "wrong";
    if (filter === "skip") return x.status === "skip" || x.status === "blank";
    return true;
  });

  const toggleOpen = (i: number) =>
    setOpen((s) => {
      const n = new Set(s);
      if (n.has(i)) n.delete(i);
      else n.add(i);
      return n;
    });

  const C = 2 * Math.PI * 52;

  return (
    <div className="dark-mesh grain relative min-h-screen">
      <div className="dark-grid-lines pointer-events-none absolute inset-0" />

      <main className="relative z-10 mx-auto max-w-5xl px-5 pt-10 pb-16">
        {/* autosubmit banner */}
        {payload.autoSubmitted && (
          <div className="animate-rise mb-6 flex items-start gap-3 rounded-2xl border border-amber-400/30 bg-amber-400/10 px-5 py-4">
            <Timer className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm font-semibold leading-relaxed text-amber-200">
              समय (30:00) समाप्त हो गया — आपका टेस्ट स्वतः सबमिट कर दिया गया था। जहाँ तक उत्तर दर्ज
              थे, उन्हीं के आधार पर रिज़ल्ट तैयार हुआ है।
            </p>
          </div>
        )}

        {/* ================= HERO SCORE ================= */}
        <section className="animate-rise overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-ink-850 to-ink-900 p-7 sm:p-9">
          <div className="grid items-center gap-8 md:grid-cols-[auto_1fr]">
            {/* donut */}
            <div className="relative mx-auto h-44 w-44">
              <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="10" />
                <circle
                  cx="60"
                  cy="60"
                  r="52"
                  fill="none"
                  stroke={grade.color}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={C}
                  strokeDashoffset={C * (1 - pct / 100)}
                  style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(0.16,1,0.3,1)", filter: `drop-shadow(0 0 10px ${grade.color}66)` }}
                />
              </svg>
              <div className="absolute inset-0 grid place-items-center text-center">
                <div>
                  <p className="font-mono text-4xl font-bold tracking-tight" style={{ color: grade.color }}>
                    {score.toFixed(2)}
                  </p>
                  <p className="font-latin text-[10px] font-extrabold uppercase tracking-[0.3em] text-white/40">
                    / {maxScore} अंक
                  </p>
                </div>
              </div>
            </div>

            <div className="text-center md:text-left">
              <p className="font-latin text-[10px] font-extrabold uppercase tracking-[0.3em] text-saffron-400">
                {test.code} · परिणाम विश्लेषण
              </p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl" style={{ color: grade.color }}>
                {grade.label}
              </h1>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/55">
                सही पर <span className="font-bold text-emerald-400">+{c.correct.toFixed(0)}</span>,
                गलत पर{" "}
                <span className="font-bold text-rose-400">−{(c.wrong / 3).toFixed(2)}</span> और खाली
                पर <span className="font-bold text-amber-400">−{(c.blank / 3).toFixed(2)}</span> कटा।{" "}
                {c.blank > 0
                  ? "खाली प्रश्नों की पेनल्टी E चुनकर बचाई जा सकती थी।"
                  : "आपने कोई प्रश्न खाली नहीं छोड़ा — बेहतरीन अनुशासन!"}
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2.5 md:justify-start">
                {newBest && (
                  <span className="flex items-center gap-1.5 rounded-full border border-emerald-400/40 bg-emerald-400/10 px-3.5 py-1.5 text-xs font-extrabold text-emerald-300">
                    <Award className="h-3.5 w-3.5" /> नया सर्वश्रेष्ठ स्कोर
                  </span>
                )}
                <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-bold text-white/65">
                  <Timer className="h-3.5 w-3.5 text-saffron-400" /> समय लगा: {fmtDur(payload.timeUsedSec)}
                </span>
                <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-bold text-white/65">
                  <Target className="h-3.5 w-3.5 text-violet-400" /> सटीकता: {accuracy}%
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* ================= STAT TILES ================= */}
        <section className="animate-rise mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6" style={{ animationDelay: "100ms" }}>
          {[
            { icon: CheckCircle2, v: String(c.correct), l: "सही उत्तर", s: "+1 प्रत्येक", cls: "text-emerald-400" },
            { icon: XCircle, v: String(c.wrong), l: "गलत उत्तर", s: "−⅓ प्रत्येक", cls: "text-rose-400" },
            { icon: SkipForward, v: String(c.skip), l: "E से छोड़े", s: "0 अंक", cls: "text-sky-400" },
            { icon: CircleDashed, v: String(c.blank), l: "खाली छोड़े", s: "−⅓ प्रत्येक", cls: "text-amber-400" },
            { icon: Target, v: `${accuracy}%`, l: "सटीकता", s: "सही / प्रयासित", cls: "text-violet-400" },
            { icon: Gauge, v: `${Math.round(timeStats.avg)} से०`, l: "औसत गति", s: "लक्ष्य 60 से०", cls: "text-saffron-400" },
          ].map((t) => (
            <div key={t.l} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
              <t.icon className={`h-5 w-5 ${t.cls}`} />
              <p className="mt-3 font-latin text-2xl font-extrabold text-white">{t.v}</p>
              <p className="mt-0.5 text-xs font-bold text-white/60">{t.l}</p>
              <p className="text-[10px] font-semibold text-white/35">{t.s}</p>
            </div>
          ))}
        </section>

        {/* ================= TIME ANALYSIS ================= */}
        <section className="animate-rise mt-6 rounded-3xl border border-white/10 bg-white/[0.04] p-6 sm:p-8" style={{ animationDelay: "160ms" }}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="flex items-center gap-2.5 text-xl font-extrabold tracking-tight">
              <Timer className="h-5 w-5 text-saffron-400" />
              प्रति-प्रश्न समय विश्लेषण
            </h2>
            <span className="font-latin text-[10px] font-extrabold uppercase tracking-[0.25em] text-white/40">
              लक्ष्य: 60 से० / प्रश्न
            </span>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3.5">
              <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-white/40">
                <Zap className="h-3.5 w-3.5 text-emerald-400" /> सबसे तेज़
              </p>
              <p className="mt-1.5 text-sm font-extrabold text-white">
                प्रश्न {timeStats.fastest + 1} <span className="text-emerald-400">({Math.round(records[timeStats.fastest].sec)} से०)</span>
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3.5">
              <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-white/40">
                <Timer className="h-3.5 w-3.5 text-rose-400" /> सबसे धीमा
              </p>
              <p className="mt-1.5 text-sm font-extrabold text-white">
                प्रश्न {timeStats.slowest + 1} <span className="text-rose-400">({Math.round(records[timeStats.slowest].sec)} से०)</span>
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3.5">
              <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-white/40">
                <TriangleAlert className="h-3.5 w-3.5 text-amber-400" /> समय-भक्षी
              </p>
              <p className="mt-1.5 text-sm font-extrabold text-white">
                {timeStats.overTarget} प्रश्न <span className="text-white/45">(60 से०+)</span>
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-ink-900/80 px-4 py-3.5">
              <p className="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-white/40">
                <Zap className="h-3.5 w-3.5 text-sky-400" /> लाइटनिंग
              </p>
              <p className="mt-1.5 text-sm font-extrabold text-white">
                {timeStats.lightning} प्रश्न <span className="text-white/45">(&lt;15 से०)</span>
              </p>
            </div>
          </div>

          {/* legend */}
          <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-[11px] font-bold text-white/50">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-emerald-500" /> सही</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-rose-500" /> गलत</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-sky-500" /> E से छोड़ा</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-amber-500" /> खाली</span>
            <span className="flex items-center gap-1.5"><span className="h-3 w-px bg-white/50" /> 60 से० लक्ष्य रेखा</span>
          </div>

          {/* bars */}
          <div className="nice-scroll mt-4 max-h-[380px] space-y-1.5 overflow-y-auto pr-1">
            {records.map((x) => (
              <div key={x.i} className="flex items-center gap-3">
                <span className="w-11 shrink-0 font-mono text-xs font-bold text-white/55">
                  प्र.{x.i + 1}
                </span>
                <span className={`${STATUS_META[x.status].dot} shrink-0`}>
                  {x.status === "correct" ? (
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  ) : x.status === "wrong" ? (
                    <XCircle className="h-3.5 w-3.5" />
                  ) : x.status === "skip" ? (
                    <SkipForward className="h-3.5 w-3.5" />
                  ) : (
                    <CircleDashed className="h-3.5 w-3.5" />
                  )}
                </span>
                <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className={`h-full rounded-full ${STATUS_META[x.status].bar} transition-all duration-700`}
                    style={{ width: `${Math.max(1.5, Math.min(100, (x.sec / timeStats.scaleMax) * 100))}%` }}
                  />
                  <div
                    className="absolute top-0 h-full w-px bg-white/45"
                    style={{ left: `${(60 / timeStats.scaleMax) * 100}%` }}
                  />
                </div>
                <span
                  className={`w-14 shrink-0 text-right font-mono text-xs font-bold ${
                    x.sec > 60 ? "text-amber-300" : "text-white/50"
                  }`}
                >
                  {Math.round(x.sec)} से०
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* ================= SOLUTIONS ================= */}
        <section className="animate-rise mt-6" style={{ animationDelay: "220ms" }}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="flex items-center gap-2.5 text-xl font-extrabold tracking-tight">
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
              उत्तर-विश्लेषण एवं व्याख्या
            </h2>
            <div className="flex gap-2">
              {(
                [
                  ["all", `सभी (${records.length})`],
                  ["wrong", `गलत (${c.wrong})`],
                  ["skip", `छोड़े गए (${c.skip + c.blank})`],
                ] as const
              ).map(([k, label]) => (
                <button
                  key={k}
                  onClick={() => setFilter(k)}
                  className={`rounded-full border px-4 py-2 text-xs font-extrabold transition-all active:scale-95 ${
                    filter === k
                      ? "border-saffron-500 bg-saffron-500 text-ink-950"
                      : "border-white/15 bg-white/5 text-white/60 hover:border-white/30"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {filtered.length === 0 && (
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-6 py-10 text-center text-sm font-semibold text-white/45">
                इस श्रेणी में कोई प्रश्न नहीं — शानदार!
              </div>
            )}
            {filtered.map((x) => {
              const isOpen = open.has(x.i);
              const meta = STATUS_META[x.status];
              return (
                <article
                  key={x.i}
                  className={`overflow-hidden rounded-2xl border transition-colors ${
                    isOpen ? "border-white/20 bg-white/[0.06]" : "border-white/10 bg-white/[0.035]"
                  }`}
                >
                  <button
                    onClick={() => toggleOpen(x.i)}
                    className="flex w-full items-center gap-3 px-4 py-4 text-left sm:px-5"
                  >
                    <span className="font-mono text-xs font-bold text-white/40">
                      {String(x.i + 1).padStart(2, "0")}
                    </span>
                    <span className={`rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold ${meta.chip}`}>
                      {meta.label}
                    </span>
                    <span className="hidden rounded-full border border-white/10 bg-white/5 px-2.5 py-0.5 text-[10px] font-extrabold text-white/50 sm:inline">
                      {TOPIC_LABEL[x.q.topic]}
                    </span>
                    <span className="ml-2 flex-1 truncate text-sm font-semibold text-white/75">
                      {x.q.q}
                    </span>
                    <span className="hidden shrink-0 font-mono text-[11px] font-bold text-white/40 sm:inline">
                      {Math.round(x.sec)} से०
                    </span>
                    <ChevronDown
                      className={`h-4 w-4 shrink-0 text-white/40 transition-transform ${isOpen ? "rotate-180" : ""}`}
                    />
                  </button>

                  {isOpen && (
                    <div className="animate-rise border-t border-white/10 px-4 py-5 sm:px-5">
                      <p className="text-[15px] font-semibold leading-relaxed text-white/90">{x.q.q}</p>
                      <p className="mt-2 flex items-center gap-1.5 text-[11px] font-semibold text-white/40">
                        <Landmark className="h-3.5 w-3.5" /> {x.q.exam}
                      </p>

                      <div className="mt-4 grid gap-2 sm:grid-cols-2">
                        <div
                          className={`rounded-xl border px-4 py-3 text-sm font-bold ${
                            x.status === "correct"
                              ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                              : x.status === "wrong"
                                ? "border-rose-400/30 bg-rose-400/10 text-rose-300"
                                : x.status === "skip"
                                  ? "border-sky-400/30 bg-sky-400/10 text-sky-300"
                                  : "border-amber-400/30 bg-amber-400/10 text-amber-300"
                          }`}
                        >
                          <p className="text-[10px] font-extrabold uppercase tracking-widest opacity-70">
                            आपका उत्तर
                          </p>
                          <p className="mt-1">
                            {x.r === null
                              ? "— खाली छोड़ा (−⅓ कटा)"
                              : x.r === "E"
                                ? "E — उत्तर नहीं दिया (0 अंक)"
                                : `${LETTERS[x.r as number]}) ${x.q.options[x.r as number]}`}
                          </p>
                        </div>
                        <div className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm font-bold text-emerald-300">
                          <p className="text-[10px] font-extrabold uppercase tracking-widest opacity-70">
                            सही उत्तर
                          </p>
                          <p className="mt-1">
                            {LETTERS[x.q.ans]}) {x.q.options[x.q.ans]}
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 rounded-xl border border-white/10 bg-ink-900/70 px-4 py-4">
                        <p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-saffron-400">
                          व्याख्या
                        </p>
                        <p className="mt-2 whitespace-pre-line text-sm leading-[1.85] text-white/70">
                          {x.q.sol}
                        </p>
                      </div>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </section>

        {/* ================= ACTIONS ================= */}
        <section className="animate-rise mt-9 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "280ms" }}>
          <button
            onClick={onRetry}
            className="flex flex-1 items-center justify-center gap-2.5 rounded-2xl bg-saffron-500 px-6 py-4 text-base font-extrabold text-ink-950 transition-all hover:bg-saffron-400 active:scale-[0.99]"
          >
            <RotateCcw className="h-5 w-5" /> पुनः प्रयास करें
          </button>
          {onNext && (
            <button
              onClick={onNext}
              className="flex flex-1 items-center justify-center gap-2.5 rounded-2xl border-2 border-emerald-400/40 bg-emerald-400/10 px-6 py-4 text-base font-extrabold text-emerald-300 transition-all hover:bg-emerald-400/20 active:scale-[0.99]"
            >
              अगला मॉक टेस्ट <ArrowRight className="h-5 w-5" />
            </button>
          )}
          <button
            onClick={onHome}
            className="flex flex-1 items-center justify-center gap-2.5 rounded-2xl border-2 border-white/15 bg-white/5 px-6 py-4 text-base font-extrabold text-white/75 transition-all hover:border-white/35 hover:text-white active:scale-[0.99]"
          >
            <Home className="h-5 w-5" /> होम पर जाएँ
          </button>
        </section>
      </main>
    </div>
  );
}
