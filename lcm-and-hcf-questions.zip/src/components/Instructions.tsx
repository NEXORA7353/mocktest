import { useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpenCheck,
  CheckCircle2,
  CircleDashed,
  FileText,
  ListChecks,
  SkipForward,
  Target,
  Timer,
  TriangleAlert,
  XCircle,
} from "lucide-react";
import type { MockTest } from "../data/types";

const RULES = [
  {
    icon: ListChecks,
    text: "इस टेस्ट में कुल 30 प्रश्न हैं — ल.स.–म.स. और प्रतिशत बारी-बारी से। प्रत्येक प्रश्न 1 अंक का है, अधिकतम अंक 30।",
    tone: "text-indigo-300",
  },
  {
    icon: Timer,
    text: "कुल समय 30 मिनट है (TRE 4.0 के 150 प्रश्न / 150 मिनट, अर्थात 1 मिनट प्रति प्रश्न के अनुपात से)। समय समाप्त होते ही टेस्ट स्वतः सबमिट हो जाएगा।",
    tone: "text-violet-300",
  },
  {
    icon: FileText,
    text: "प्रत्येक प्रश्न में 5 विकल्प A, B, C, D, E दिखेंगे। A–D में से केवल एक सही उत्तर है।",
    tone: "text-saffron-300",
  },
  {
    icon: CheckCircle2,
    text: "सही उत्तर पर +1 अंक मिलेगा।",
    tone: "text-emerald-300",
  },
  {
    icon: XCircle,
    text: "गलत उत्तर पर −⅓ (एक-तिहाई) अंक कटेगा (नेगेटिव मार्किंग)।",
    tone: "text-rose-300",
  },
  {
    icon: SkipForward,
    text: "यदि किसी प्रश्न का उत्तर नहीं देना चाहते, तो विकल्प E चुनें — इससे न अंक मिलेगा, न कटेगा।",
    tone: "text-sky-300",
  },
  {
    icon: CircleDashed,
    text: "सबसे जरूरी नियम: A से E तक में से कोई भी विकल्प न चुनने (प्रश्न खाली छोड़ने) पर भी −⅓ अंक कटेगा। अतः कोई भी प्रश्न खाली न छोड़ें — उत्तर न आए तो E अवश्य चुनें।",
    tone: "text-amber-300",
  },
  {
    icon: Target,
    text: "'समीक्षा' बटन से प्रश्न फ्लैग कर सकते हैं और पैलेट से किसी भी प्रश्न पर सीधे जा सकते हैं। रिज़ल्ट में प्रत्येक प्रश्न का समय-विश्लेषण, सटीकता और पूर्ण व्याख्या दिखेगी।",
    tone: "text-teal-300",
  },
];

export default function Instructions({
  test,
  onBack,
  onStart,
}: {
  test: MockTest;
  onBack: () => void;
  onStart: () => void;
}) {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="dark-mesh grain relative flex min-h-screen flex-col">
      <div className="dark-grid-lines pointer-events-none absolute inset-0" />

      <header className="relative z-10 mx-auto flex w-full max-w-4xl items-center justify-between px-5 pt-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-bold text-white/70 transition-colors hover:border-white/25 hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" /> वापस
        </button>
        <span className="rounded-full border border-saffron-500/40 bg-saffron-500/10 px-4 py-1.5 font-latin text-[10px] font-extrabold uppercase tracking-[0.25em] text-saffron-300">
          {test.code}
        </span>
      </header>

      <main className="relative z-10 mx-auto w-full max-w-4xl flex-1 px-5 pt-10 pb-12">
        <div className="animate-rise">
          <p className="text-xs font-bold tracking-widest text-saffron-400 uppercase">
            परीक्षा शुरू करने से पहले पढ़ें
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">
            {test.title} — <span className="text-saffron-400">सामान्य निर्देश</span>
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-white/55">{test.tagline}</p>

          <div className="mt-5 flex flex-wrap gap-2.5 text-xs font-bold text-white/70">
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5">
              <ListChecks className="h-3.5 w-3.5 text-saffron-400" /> 30 प्रश्न
            </span>
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5">
              <Timer className="h-3.5 w-3.5 text-saffron-400" /> 30 मिनट
            </span>
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5">
              <Target className="h-3.5 w-3.5 text-saffron-400" /> +1 / −⅓ मार्किंग
            </span>
          </div>
        </div>

        <div
          className="animate-rise mt-8 overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] backdrop-blur"
          style={{ animationDelay: "120ms" }}
        >
          <div className="flex items-center gap-3 border-b border-white/10 bg-white/[0.03] px-6 py-4">
            <BookOpenCheck className="h-5 w-5 text-saffron-400" />
            <h2 className="text-sm font-extrabold tracking-wide text-white/85">
              TRE 4.0 परीक्षा नियमावली
            </h2>
          </div>
          <ol className="divide-y divide-white/[0.06]">
            {RULES.map((r, i) => (
              <li key={i} className="flex gap-4 px-6 py-4">
                <span className="font-latin mt-0.5 w-7 shrink-0 text-sm font-extrabold text-white/30">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <r.icon className={`mt-0.5 h-5 w-5 shrink-0 ${r.tone}`} />
                <p className="text-sm leading-relaxed text-white/70">{r.text}</p>
              </li>
            ))}
          </ol>
        </div>

        <div
          className="animate-rise mt-6 flex items-start gap-3 rounded-2xl border border-amber-400/25 bg-amber-400/10 px-5 py-4"
          style={{ animationDelay: "200ms" }}
        >
          <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
          <p className="text-sm leading-relaxed text-amber-200/90">
            <span className="font-extrabold">चेतावनी:</span> असली TRE 4.0 की भाँति यहाँ भी अनउत्तरित
            (बिना विकल्प चुना हुआ) प्रश्न <span className="font-extrabold">−⅓ अंक</span> की कटौती
            कराएगा। इसलिए जहाँ उत्तर न आए, वहाँ <span className="font-extrabold">E</span> चुनना सबसे
            सुरक्षित है।
          </p>
        </div>

        <label
          className="animate-rise mt-6 flex cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 transition-colors hover:border-white/25"
          style={{ animationDelay: "280ms" }}
        >
          <input
            type="checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="h-5 w-5 cursor-pointer accent-[#f5a524]"
          />
          <span className="text-sm font-semibold text-white/75">
            मैंने सभी निर्देश ध्यानपूर्वक पढ़ लिए हैं और TRE 4.0 मार्किंग नियम समझता/समझती हूँ।
          </span>
        </label>

        <div className="animate-rise mt-7" style={{ animationDelay: "340ms" }}>
          <button
            onClick={onStart}
            disabled={!agreed}
            className="group flex w-full items-center justify-center gap-3 rounded-2xl bg-saffron-500 px-6 py-4.5 text-base font-extrabold text-ink-950 transition-all hover:bg-saffron-400 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-35 sm:py-5"
          >
            टाइमर शुरू करें — टेस्ट प्रारंभ
            <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
          </button>
          <p className="mt-3 text-center text-[11px] font-semibold tracking-wide text-white/35">
            शुरू करते ही 30:00 मिनट का काउंटडाउन चालू हो जाएगा
          </p>
        </div>
      </main>
    </div>
  );
}
