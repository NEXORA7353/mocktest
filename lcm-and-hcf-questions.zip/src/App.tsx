import { useState } from "react";
import Landing from "./components/Landing";
import Instructions from "./components/Instructions";
import TestRunner from "./components/TestRunner";
import Result from "./components/Result";
import { getTest, tests } from "./data";
import type { ResultPayload } from "./data/types";

type Screen =
  | { name: "home" }
  | { name: "instructions"; testId: number }
  | { name: "test"; testId: number; attempt: number }
  | { name: "result"; testId: number; payload: ResultPayload };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ name: "home" });

  const go = (s: Screen) => {
    setScreen(s);
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  if (screen.name === "instructions") {
    const test = getTest(screen.testId);
    return (
      <Instructions
        test={test}
        onBack={() => go({ name: "home" })}
        onStart={() => go({ name: "test", testId: test.id, attempt: Date.now() })}
      />
    );
  }

  if (screen.name === "test") {
    const test = getTest(screen.testId);
    return (
      <TestRunner
        key={screen.attempt}
        test={test}
        onFinish={(payload) => go({ name: "result", testId: test.id, payload })}
        onQuit={() => go({ name: "home" })}
      />
    );
  }

  if (screen.name === "result") {
    const test = getTest(screen.testId);
    const hasNext = screen.testId < tests.length;
    return (
      <Result
        test={test}
        payload={screen.payload}
        onRetry={() => go({ name: "test", testId: test.id, attempt: Date.now() })}
        onHome={() => go({ name: "home" })}
        onNext={hasNext ? () => go({ name: "instructions", testId: screen.testId + 1 }) : undefined}
      />
    );
  }

  return <Landing onSelect={(testId) => go({ name: "instructions", testId })} />;
}
